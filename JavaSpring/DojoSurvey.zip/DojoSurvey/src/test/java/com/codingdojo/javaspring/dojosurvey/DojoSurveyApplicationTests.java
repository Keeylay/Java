package com.codingdojo.javaspring.dojosurvey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoSurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
